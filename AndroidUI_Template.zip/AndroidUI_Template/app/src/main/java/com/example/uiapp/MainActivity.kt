package com.example.uiapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tv1 = findViewById<TextView>(R.id.tvTitle)
        val tv2 = findViewById<TextView>(R.id.tvSubtitle)
        val btn = findViewById<MaterialButton>(R.id.btnAction)

        btn.setOnClickListener {
            tv1.text = "Texte mis à jour ✅"
            tv2.text = "Action du bouton bien reçue 🎯"
        }
    }
}