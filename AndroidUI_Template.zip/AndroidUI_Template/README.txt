# AndroidUI_Template (sans Android Studio)

Projet Android Kotlin prêt à l'emploi avec une UI simple (2 TextView + 1 bouton), compilable avec Gradle en ligne de commande.
Ouvrez-le dans Visual Studio Code si vous voulez (pas obligatoire).

## Prérequis
- JDK 17+ (`java -version`)
- Android SDK command-line tools installés
  - sdkmanager --install "platform-tools" "platforms;android-34" "build-tools;34.0.0"
  - ADB disponible : `adb version`
- (Optionnel) Gradle installé, sinon utilisez le wrapper après l’avoir créé : `gradle wrapper`

## Build (Linux/Mac)
```bash
./gradlew wrapper          # si le wrapper n'existe pas encore
./gradlew assembleDebug
```

## Build (Windows PowerShell)
```powershell
gradlew.bat wrapper        # si le wrapper n'existe pas encore
gradlew.bat assembleDebug
```

## APK généré
- `app/build/outputs/apk/debug/app-debug.apk`

## Installer sur le téléphone (USB)
```bash
adb devices
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## UI fournie
- Deux TextView affichent un titre et un sous-titre
- Un bouton "Changer le texte" met à jour les deux TextView