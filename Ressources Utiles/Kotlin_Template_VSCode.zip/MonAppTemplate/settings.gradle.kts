rootProject.name = "MonAppTemplate"
include(":app")
